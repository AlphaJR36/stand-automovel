#ifndef HEADER_H
#define HEADER_H

#include <stdio.h>

void header();
void headerLogin();
void headerSignIn();
void headerSignUp();
void headerAddNewCar();
void headerShowCars();
void headerFindByModel();
void headerRemoveCar();
void headerShowPurchaseHistory();
void headerBuyCar();
void headerTerminateSession();

#endif